import type { LogLine } from "../types/api";

type MessagePanelProps = {
  lines: LogLine[];
  onClear: () => void;
};

export function MessagePanel({ lines, onClear }: MessagePanelProps) {
  const text = lines.map((line) => line.text).join("\n");

  async function copy() {
    await navigator.clipboard.writeText(text);
  }

  return (
    <section className="messages">
      <header>
        <span>訊息</span>
        <div>
          <button type="button" onClick={copy} disabled={!text}>
            複製
          </button>
          <button type="button" onClick={onClear} disabled={!text}>
            清除
          </button>
        </div>
      </header>
      <pre>
        {lines.map((line, index) => (
          <div key={`${index}-${line.text.slice(0, 24)}`} className={`log-${line.level}`}>
            {line.text}
          </div>
        ))}
      </pre>
    </section>
  );
}
