import createPlotlyComponent from "react-plotly.js/factory";
import Plotly from "plotly.js-dist-min";
import type { S11Result } from "../types/api";

const Plot = createPlotlyComponent(Plotly);

type PlotPanelProps = {
  result: S11Result | null;
  running: boolean;
};

export function PlotPanel({ result, running }: PlotPanelProps) {
  if (!result) {
    return (
      <section className="plot-pane">
        <div className="plot-empty">
          <p className="eyebrow">dB(S11)</p>
          <h2>{running ? "HFSS 解題中…" : "尚未有掃頻結果"}</h2>
          <p>
            {running
              ? "Setup1 : Sweep1 完成後，dB(S11) 會顯示在這個中央區域。"
              : "左側設定材料、尺寸與頻率範圍，按模擬。完成後曲線會畫在這裡。"}
          </p>
        </div>
      </section>
    );
  }

  const hasBw = result.bw_ghz !== null && result.f_low_ghz !== null && result.f_high_ghz !== null;
  const yMin = Math.min(...result.s11_db) - 1;
  const yMax = Math.max(...result.s11_db) + 0.5;

  return (
    <section className="plot-pane">
      <div className="chips">
        <div>
          <span>fres</span>
          <strong>{result.f_res_ghz.toFixed(4)} GHz</strong>
        </div>
        <div>
          <span>S11</span>
          <strong>{result.s11_min_db.toFixed(2)} dB</strong>
        </div>
        <div>
          <span>3 dB BW</span>
          <strong>{hasBw ? `${(result.bw_ghz! * 1000).toFixed(1)} MHz` : "—"}</strong>
        </div>
      </div>
      <Plot
        className="s11-plot"
        data={[
          {
            x: result.freq_ghz,
            y: result.s11_db,
            type: "scatter",
            mode: "lines",
            name: result.expression,
            line: { color: "#4fd2ff", width: 2.4 },
            hovertemplate: "f = %{x:.4f} GHz<br>dB(S11) = %{y:.3f} dB<extra></extra>",
          },
          {
            x: hasBw ? [result.f_low_ghz, result.f_res_ghz, result.f_high_ghz] : [result.f_res_ghz],
            y: hasBw ? [result.threshold_db, result.s11_min_db, result.threshold_db] : [result.s11_min_db],
            type: "scatter",
            mode: "markers",
            name: "markers",
            marker: {
              size: 9,
              color: hasBw ? ["#7dffc2", "#ffc14a", "#7dffc2"] : ["#ffc14a"],
            },
            hoverinfo: "skip",
          },
        ]}
        layout={{
          autosize: true,
          paper_bgcolor: "#101c28",
          plot_bgcolor: "#0a1620",
          font: { family: "IBM Plex Mono, monospace", color: "#d6e6f2", size: 12 },
          margin: { l: 58, r: 16, t: 20, b: 48 },
          xaxis: { title: { text: "Frequency (GHz)" }, gridcolor: "#1d3244", zeroline: false },
          yaxis: { title: { text: "dB(S11)" }, gridcolor: "#1d3244", zeroline: false },
          showlegend: false,
          hovermode: "x unified",
          shapes: [
            ...(hasBw
              ? [
                  {
                    type: "rect" as const,
                    xref: "x",
                    yref: "y",
                    x0: result.f_low_ghz!,
                    x1: result.f_high_ghz!,
                    y0: yMin,
                    y1: result.threshold_db,
                    fillcolor: "rgba(125, 255, 194, 0.12)",
                    line: { width: 0 },
                  },
                  {
                    type: "line" as const,
                    x0: result.freq_ghz[0],
                    x1: result.freq_ghz[result.freq_ghz.length - 1],
                    y0: result.threshold_db,
                    y1: result.threshold_db,
                    line: { color: "#7dffc2", width: 1, dash: "dash" },
                  },
                ]
              : []),
            {
              type: "line" as const,
              x0: result.f_res_ghz,
              x1: result.f_res_ghz,
              y0: yMin,
              y1: yMax,
              line: { color: "#ffc14a", width: 1.5, dash: "dot" },
            },
          ],
          annotations: [
            {
              x: result.f_res_ghz,
              y: result.s11_min_db,
              text: `fres = ${result.f_res_ghz.toFixed(4)} GHz`,
              ax: 36,
              ay: 36,
              font: { color: "#ffc14a", size: 12 },
              arrowcolor: "#ffc14a",
              bgcolor: "rgba(7,16,24,0.8)",
            },
            ...(hasBw
              ? [
                  {
                    x: (result.f_low_ghz! + result.f_high_ghz!) / 2,
                    y: result.threshold_db,
                    text: `3 dB BW = ${(result.bw_ghz! * 1000).toFixed(1)} MHz`,
                    showarrow: false,
                    yshift: 14,
                    font: { color: "#7dffc2", size: 12 },
                    bgcolor: "rgba(7,16,24,0.75)",
                  },
                ]
              : []),
          ],
        }}
        config={{ displaylogo: false, responsive: true }}
        useResizeHandler
        style={{ width: "100%", height: "100%" }}
      />
    </section>
  );
}
