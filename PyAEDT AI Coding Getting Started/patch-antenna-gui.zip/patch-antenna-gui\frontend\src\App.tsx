import { useEffect, useMemo, useState } from "react";
import { cancelJob, getJob, startJob } from "./api/client";
import { MenuBar } from "./components/MenuBar";
import { MessagePanel } from "./panels/MessagePanel";
import { ParamPanel } from "./panels/ParamPanel";
import { PlotPanel } from "./panels/PlotPanel";
import { defaultParams, type JobStatus, type LogLine, type SimulationRequest } from "./types/api";

export default function App() {
  const [params, setParams] = useState<SimulationRequest>(defaultParams);
  const [job, setJob] = useState<JobStatus | null>(null);
  const [localLogs, setLocalLogs] = useState<LogLine[]>([]);
  const [consoleOpen, setConsoleOpen] = useState(true);
  const [aboutOpen, setAboutOpen] = useState(false);

  const [clearedAt, setClearedAt] = useState(0);
  const running = job?.state === "queued" || job?.state === "running";
  const logs = useMemo(() => [...localLogs, ...(job?.messages ?? [])], [localLogs, job]);
  const visibleLogs = logs.slice(clearedAt);

  useEffect(() => {
    if (!job || (job.state !== "queued" && job.state !== "running")) {
      return;
    }
    const timer = window.setInterval(async () => {
      try {
        const next = await getJob(job.job_id);
        setJob(next);
      } catch (error) {
        setLocalLogs((prev) => [
          ...prev,
          { level: "error", text: error instanceof Error ? error.message : String(error) },
        ]);
      }
    }, 800);
    return () => window.clearInterval(timer);
  }, [job]);

  async function simulate() {
    if (params.f_stop_ghz <= params.f_start_ghz) {
      setLocalLogs((prev) => [...prev, { level: "error", text: "掃頻終點必須大於起點" }]);
      return;
    }
    try {
      const started = await startJob(params);
      setJob(started);
      setLocalLogs((prev) => [...prev, { level: "info", text: `Job ${started.job_id} started` }]);
    } catch (error) {
      setLocalLogs((prev) => [
        ...prev,
        { level: "error", text: error instanceof Error ? error.message : String(error) },
      ]);
    }
  }

  async function stop() {
    if (!job) {
      return;
    }
    await cancelJob(job.job_id);
  }

  return (
    <div className={`shell ${consoleOpen ? "" : "console-off"}`}>
      <MenuBar
        running={running}
        consoleOpen={consoleOpen}
        onReset={() => setParams(defaultParams)}
        onSimulate={() => void simulate()}
        onStop={() => void stop()}
        onToggleConsole={() => setConsoleOpen((open) => !open)}
        onAbout={() => setAboutOpen(true)}
      />
      <div className="workspace">
        <ParamPanel
          params={params}
          running={running}
          onChange={setParams}
          onSimulate={() => void simulate()}
        />
        <PlotPanel result={job?.result ?? null} running={running} />
      </div>
      {consoleOpen ? (
        <MessagePanel
          lines={visibleLogs}
          onClear={() => {
            setLocalLogs([]);
            setClearedAt(logs.length);
          }}
        />
      ) : null}
      {aboutOpen ? (
        <div className="modal" role="dialog">
          <div className="modal-card">
            <h2>HFSS 3D Patch Antenna</h2>
            <p>左側輸入材料、尺寸與頻率，按模擬後中央顯示 dB(S11)。後端以 PyAEDT 建立 HFSS 3D probe-fed patch，不是 Layout。</p>
            <button type="button" onClick={() => setAboutOpen(false)}>
              關閉
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}
