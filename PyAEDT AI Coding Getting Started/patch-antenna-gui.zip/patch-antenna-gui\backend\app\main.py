from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from backend.app.jobs import store
from backend.app.models import JobStatus, SimulationRequest

ROOT = Path(__file__).resolve().parents[2]
DIST = ROOT / "frontend" / "dist"

app = FastAPI(title="Patch Antenna GUI")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/api/jobs", response_model=JobStatus)
def start_job(payload: SimulationRequest) -> JobStatus:
    if payload.f_stop_ghz <= payload.f_start_ghz:
        raise HTTPException(status_code=400, detail="Stop frequency must be greater than start frequency")
    job_id = store.create(payload)
    status = store.status(job_id)
    assert status is not None
    return status


@app.get("/api/jobs/{job_id}", response_model=JobStatus)
def get_job(job_id: str) -> JobStatus:
    status = store.status(job_id)
    if status is None:
        raise HTTPException(status_code=404, detail="Unknown job")
    return status


@app.post("/api/jobs/{job_id}/cancel", response_model=JobStatus)
def cancel_job(job_id: str) -> JobStatus:
    store.cancel(job_id)
    status = store.status(job_id)
    if status is None:
        raise HTTPException(status_code=404, detail="Unknown job")
    return status


if DIST.exists():
    app.mount("/", StaticFiles(directory=DIST, html=True), name="frontend")
