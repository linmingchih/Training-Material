type MenuBarProps = {
  running: boolean;
  consoleOpen: boolean;
  onReset: () => void;
  onSimulate: () => void;
  onStop: () => void;
  onToggleConsole: () => void;
  onAbout: () => void;
};

export function MenuBar({
  running,
  consoleOpen,
  onReset,
  onSimulate,
  onStop,
  onToggleConsole,
  onAbout,
}: MenuBarProps) {
  return (
    <nav className="menu-bar" aria-label="Application">
      <details>
        <summary>檔案</summary>
        <div className="menu-drop">
          <button type="button" onClick={onReset}>
            還原預設
          </button>
        </div>
      </details>
      <details>
        <summary>執行</summary>
        <div className="menu-drop">
          <button type="button" onClick={onSimulate} disabled={running}>
            模擬
          </button>
          <button type="button" onClick={onStop} disabled={!running}>
            停止
          </button>
        </div>
      </details>
      <details>
        <summary>檢視</summary>
        <div className="menu-drop">
          <button type="button" onClick={onToggleConsole}>
            {consoleOpen ? "隱藏訊息" : "顯示訊息"}
          </button>
        </div>
      </details>
      <details>
        <summary>說明</summary>
        <div className="menu-drop">
          <button type="button" onClick={onAbout}>
            關於
          </button>
        </div>
      </details>
    </nav>
  );
}
