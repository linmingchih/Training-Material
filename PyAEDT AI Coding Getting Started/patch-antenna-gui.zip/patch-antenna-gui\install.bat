@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

echo.
echo === Patch Antenna GUI : first-time install ===
echo.

set "PYVER=3.12.10"
set "PYURL=https://www.python.org/ftp/python/%PYVER%/python-%PYVER%-amd64.exe"
set "PYSETUP=%TEMP%\python-%PYVER%-amd64.exe"
set "PYHOME=%LocalAppData%\Programs\Python\Python312"
set "PY312="

set "NODEVER=22.23.2"
set "NODEZIPURL=https://nodejs.org/dist/v%NODEVER%/node-v%NODEVER%-win-x64.zip"
set "NODEZIP=%TEMP%\node-v%NODEVER%-win-x64.zip"
set "NODEHOME=%LocalAppData%\Programs\node-v%NODEVER%-win-x64"
set "NPM="

call :find_py312
if defined PY312 goto :have_python

echo Python 3.12 was not found.
echo Downloading official installer from python.org ...
echo   %PYURL%
curl.exe -L --fail --retry 3 --connect-timeout 30 -o "%PYSETUP%" "%PYURL%"
if errorlevel 1 (
  echo Download failed. Check internet access and try again.
  echo Manual download: %PYURL%
  pause
  exit /b 1
)

echo Installing Python %PYVER% for this user ^(PATH will include 3.12^) ...
"%PYSETUP%" /passive InstallAllUsers=0 PrependPath=1 Include_launcher=1 Include_pip=1 Include_test=0 SimpleInstall=1 TargetDir="%PYHOME%"
if errorlevel 1 (
  echo Python installer failed or was cancelled.
  pause
  exit /b 1
)

call :find_py312
if not defined PY312 (
  if exist "%PYHOME%\python.exe" set "PY312=%PYHOME%\python.exe"
)
if not defined PY312 (
  echo Python 3.12 installed, but python.exe was not found at:
  echo   %PYHOME%\python.exe
  echo Close this window, open a new Command Prompt, and run install.bat again.
  pause
  exit /b 1
)

:have_python
echo Using Python 3.12: %PY312%
"%PY312%" -c "import sys; print(sys.version)"

if not exist ".venv\Scripts\python.exe" (
  echo Creating virtual environment .venv ...
  "%PY312%" -m venv .venv
  if errorlevel 1 (
    echo Failed to create .venv
    pause
    exit /b 1
  )
) else (
  echo .venv already exists, reusing it.
)

echo Installing Python packages ...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto :fail
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :fail

if exist "frontend\dist\index.html" (
  echo Prebuilt UI found at frontend\dist - skipping Node.js / npm.
  goto :done
)

call :find_npm
if defined NPM goto :have_npm

echo Node.js / npm was not found.
echo Downloading official Node.js %NODEVER% ^(Windows x64 zip^) ...
echo   %NODEZIPURL%
curl.exe -L --fail --retry 3 --connect-timeout 30 -o "%NODEZIP%" "%NODEZIPURL%"
if errorlevel 1 (
  echo Download failed. Check internet access and try again.
  echo Manual download: %NODEZIPURL%
  pause
  exit /b 1
)

if not exist "%LocalAppData%\Programs" mkdir "%LocalAppData%\Programs"
echo Extracting Node.js to:
echo   %NODEHOME%
if exist "%NODEHOME%" rd /s /q "%NODEHOME%"
if exist "%TEMP%\node-v%NODEVER%-win-x64" rd /s /q "%TEMP%\node-v%NODEVER%-win-x64"
powershell.exe -NoProfile -Command "Expand-Archive -LiteralPath '%NODEZIP%' -DestinationPath '%TEMP%' -Force"
if errorlevel 1 (
  echo Failed to extract Node.js zip.
  pause
  exit /b 1
)
move "%TEMP%\node-v%NODEVER%-win-x64" "%NODEHOME%" >nul
if not exist "%NODEHOME%\npm.cmd" (
  echo npm.cmd not found after extract: %NODEHOME%\npm.cmd
  pause
  exit /b 1
)

call :find_npm
if not defined NPM set "NPM=%NODEHOME%\npm.cmd"
if not exist "%NPM%" (
  echo Node.js was extracted, but npm was not found.
  pause
  exit /b 1
)

:have_npm
echo Using npm: %NPM%
set "PATH=%NODEHOME%;%ProgramFiles%\nodejs;%PATH%"

echo Installing frontend packages and building UI ...
pushd frontend
call "%NPM%" install
if errorlevel 1 (
  popd
  goto :fail
)
call "%NPM%" run build
if errorlevel 1 (
  popd
  goto :fail
)
popd

:done
echo.
echo Install finished. Double-click run.bat to open the GUI.
pause
exit /b 0

:fail
echo.
echo Install failed. See the messages above.
pause
exit /b 1

:find_py312
set "PY312="
if exist "%LocalAppData%\Programs\Python\Python312\python.exe" (
  "%LocalAppData%\Programs\Python\Python312\python.exe" -c "import sys; raise SystemExit(0 if sys.version_info[:2]==(3,12) else 1)" >nul 2>&1
  if not errorlevel 1 (
    set "PY312=%LocalAppData%\Programs\Python\Python312\python.exe"
    exit /b 0
  )
)
if exist "%ProgramFiles%\Python312\python.exe" (
  "%ProgramFiles%\Python312\python.exe" -c "import sys; raise SystemExit(0 if sys.version_info[:2]==(3,12) else 1)" >nul 2>&1
  if not errorlevel 1 (
    set "PY312=%ProgramFiles%\Python312\python.exe"
    exit /b 0
  )
)
py -3.12 -c "import sys; raise SystemExit(0 if sys.version_info[:2]==(3,12) else 1)" >nul 2>&1
if not errorlevel 1 (
  for /f "delims=" %%I in ('py -3.12 -c "import sys; print(sys.executable)" 2^>nul') do set "PY312=%%I"
  if defined PY312 exit /b 0
)
where python >nul 2>&1
if not errorlevel 1 (
  python -c "import sys; raise SystemExit(0 if sys.version_info[:2]==(3,12) else 1)" >nul 2>&1
  if not errorlevel 1 (
    for /f "delims=" %%I in ('python -c "import sys; print(sys.executable)" 2^>nul') do set "PY312=%%I"
  )
)
exit /b 0

:find_npm
set "NPM="
if exist "%ProgramFiles%\nodejs\npm.cmd" (
  set "NPM=%ProgramFiles%\nodejs\npm.cmd"
  exit /b 0
)
if exist "%LocalAppData%\Programs\nodejs\npm.cmd" (
  set "NPM=%LocalAppData%\Programs\nodejs\npm.cmd"
  exit /b 0
)
if exist "%NODEHOME%\npm.cmd" (
  set "NPM=%NODEHOME%\npm.cmd"
  exit /b 0
)
where npm >nul 2>&1
if not errorlevel 1 (
  for /f "delims=" %%I in ('where npm') do (
    set "NPM=%%I"
    exit /b 0
  )
)
exit /b 0
