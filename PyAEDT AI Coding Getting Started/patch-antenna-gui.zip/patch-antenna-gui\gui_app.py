"""Launch the patch-antenna pywebview GUI (FastAPI + Vite frontend)."""

from __future__ import annotations

import os
import socket
import subprocess
import sys
import threading
import time
from pathlib import Path

import uvicorn
import webview

ROOT = Path(__file__).resolve().parent
HOST = "127.0.0.1"
PORT = 8000
DIST = ROOT / "frontend" / "dist"

os.chdir(ROOT)
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def port_open() -> bool:
    sock = socket.socket()
    sock.settimeout(0.3)
    try:
        sock.connect((HOST, PORT))
        return True
    except OSError:
        return False
    finally:
        sock.close()


def ensure_frontend() -> None:
    if DIST.exists() and (DIST / "index.html").exists() and "--build" not in sys.argv:
        return
    print("Building frontend...")
    subprocess.check_call(["npm", "run", "build"], cwd=ROOT / "frontend")


def start_api() -> None:
    uvicorn.run(
        "backend.app.main:app",
        host=HOST,
        port=PORT,
        reload=False,
        log_level="info",
    )


ensure_frontend()
if not port_open():
    thread = threading.Thread(target=start_api, daemon=True)
    thread.start()
    for _ in range(80):
        if port_open():
            break
        time.sleep(0.25)
    else:
        raise RuntimeError("FastAPI did not start on port 8000")

webview.create_window(
    "HFSS 3D Patch Antenna",
    f"http://{HOST}:{PORT}/",
    width=1440,
    height=920,
    min_size=(1100, 720),
)
webview.start()
