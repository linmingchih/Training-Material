@echo off
setlocal EnableExtensions
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
  echo .venv is missing. Run install.bat first.
  pause
  exit /b 1
)
if not exist "frontend\dist\index.html" (
  echo Frontend UI is missing. Run install.bat first.
  pause
  exit /b 1
)

echo Starting HFSS 3D Patch Antenna GUI ...
".venv\Scripts\python.exe" gui_app.py
if errorlevel 1 (
  echo.
  echo GUI exited with an error.
  pause
  exit /b 1
)
exit /b 0
