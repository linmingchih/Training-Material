import type { SimulationRequest, SubstrateLibrary } from "../types/api";

type ParamPanelProps = {
  params: SimulationRequest;
  running: boolean;
  onChange: (next: SimulationRequest) => void;
  onSimulate: () => void;
};

function num(value: string, fallback: number): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

export function ParamPanel({ params, running, onChange, onSimulate }: ParamPanelProps) {
  const custom = params.substrate_library === "custom";
  const lengthText = params.patch_length_mm === null ? "" : String(params.patch_length_mm);

  return (
    <aside className="params">
      <header className="pane-label">材料／尺寸／頻率</header>

      <fieldset disabled={running}>
        <legend>材料</legend>
        <label>
          基板
          <select
            value={params.substrate_library}
            onChange={(event) =>
              onChange({
                ...params,
                substrate_library: event.target.value as SubstrateLibrary,
              })
            }
          >
            <option value="FR4_epoxy">FR4_epoxy</option>
            <option value="Duroid (tm)">Duroid (tm)</option>
            <option value="custom">自訂 εr / tanδ</option>
          </select>
        </label>
        <label>
          介電常數 εr
          <input
            type="number"
            step="0.01"
            disabled={!custom}
            value={params.permittivity}
            onChange={(event) => onChange({ ...params, permittivity: num(event.target.value, 4.4) })}
          />
        </label>
        <label>
          損耗正切
          <input
            type="number"
            step="0.001"
            disabled={!custom}
            value={params.loss_tangent}
            onChange={(event) => onChange({ ...params, loss_tangent: num(event.target.value, 0.02) })}
          />
        </label>
        <label>
          金屬
          <input
            type="text"
            value={params.metal_material}
            onChange={(event) => onChange({ ...params, metal_material: event.target.value })}
          />
        </label>
        <label>
          金屬厚度 (mm)
          <input
            type="number"
            step="0.001"
            value={params.metal_thickness_mm}
            onChange={(event) =>
              onChange({ ...params, metal_thickness_mm: num(event.target.value, 0.035) })
            }
          />
        </label>
      </fieldset>

      <fieldset disabled={running}>
        <legend>尺寸</legend>
        <label>
          Patch 寬度 (mm)
          <input
            type="number"
            step="0.1"
            value={params.patch_width_mm}
            onChange={(event) => onChange({ ...params, patch_width_mm: num(event.target.value, 38) })}
          />
        </label>
        <label>
          Patch 長度 (mm)
          <input
            type="number"
            step="0.1"
            placeholder="空白＝依頻率自動算"
            value={lengthText}
            onChange={(event) => {
              const raw = event.target.value.trim();
              onChange({
                ...params,
                patch_length_mm: raw === "" ? null : num(raw, 0),
              });
            }}
          />
        </label>
        <label>
          基板厚度 (mm)
          <input
            type="number"
            step="0.05"
            value={params.substrate_thickness_mm}
            onChange={(event) =>
              onChange({ ...params, substrate_thickness_mm: num(event.target.value, 1.6) })
            }
          />
        </label>
        <label>
          Probe 偏移 (0–1)
          <input
            type="number"
            step="0.05"
            min={0}
            max={1}
            value={params.probe_rel_x}
            onChange={(event) => onChange({ ...params, probe_rel_x: num(event.target.value, 0.3) })}
          />
        </label>
        <label>
          Probe 半徑 (mm)
          <input
            type="number"
            step="0.05"
            value={params.probe_radius_mm}
            onChange={(event) => onChange({ ...params, probe_radius_mm: num(event.target.value, 0.6) })}
          />
        </label>
        <label>
          輻射箱餘裕 (mm)
          <input
            type="number"
            step="1"
            value={params.airbox_pad_mm}
            onChange={(event) => onChange({ ...params, airbox_pad_mm: num(event.target.value, 30) })}
          />
        </label>
      </fieldset>

      <fieldset disabled={running}>
        <legend>頻率</legend>
        <label>
          中心頻率 (GHz)
          <input
            type="number"
            step="0.01"
            value={params.f_center_ghz}
            onChange={(event) => onChange({ ...params, f_center_ghz: num(event.target.value, 2.4) })}
          />
        </label>
        <label>
          掃頻起點 (GHz)
          <input
            type="number"
            step="0.01"
            value={params.f_start_ghz}
            onChange={(event) => onChange({ ...params, f_start_ghz: num(event.target.value, 2.0) })}
          />
        </label>
        <label>
          掃頻終點 (GHz)
          <input
            type="number"
            step="0.01"
            value={params.f_stop_ghz}
            onChange={(event) => onChange({ ...params, f_stop_ghz: num(event.target.value, 2.8) })}
          />
        </label>
        <label>
          Adaptive 次數
          <input
            type="number"
            step="1"
            min={2}
            max={20}
            value={params.max_passes}
            onChange={(event) => onChange({ ...params, max_passes: num(event.target.value, 6) })}
          />
        </label>
        <label className="check">
          <input
            type="checkbox"
            checked={params.graphical_aedt}
            onChange={(event) => onChange({ ...params, graphical_aedt: event.target.checked })}
          />
          顯示 AEDT 視窗
        </label>
      </fieldset>

      <button type="button" className="run-btn" onClick={onSimulate} disabled={running}>
        {running ? "模擬中…" : "模擬"}
      </button>
    </aside>
  );
}
