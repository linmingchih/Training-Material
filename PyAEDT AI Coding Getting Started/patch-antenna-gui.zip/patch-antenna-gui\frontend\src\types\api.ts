export type SubstrateLibrary = "custom" | "FR4_epoxy" | "Duroid (tm)";

export type SimulationRequest = {
  substrate_library: SubstrateLibrary;
  permittivity: number;
  loss_tangent: number;
  metal_material: string;
  metal_thickness_mm: number;
  patch_width_mm: number;
  patch_length_mm: number | null;
  substrate_thickness_mm: number;
  probe_rel_x: number;
  probe_radius_mm: number;
  airbox_pad_mm: number;
  f_center_ghz: number;
  f_start_ghz: number;
  f_stop_ghz: number;
  max_passes: number;
  graphical_aedt: boolean;
};

export type LogLine = {
  level: "info" | "warning" | "error";
  text: string;
};

export type S11Result = {
  expression: string;
  freq_ghz: number[];
  s11_db: number[];
  f_res_ghz: number;
  s11_min_db: number;
  threshold_db: number;
  f_low_ghz: number | null;
  f_high_ghz: number | null;
  bw_ghz: number | null;
  frac_bw_pct: number | null;
  q_factor: number | null;
};

export type JobStatus = {
  job_id: string;
  state: "queued" | "running" | "completed" | "failed" | "cancelled";
  messages: LogLine[];
  result: S11Result | null;
  error: string | null;
};

export const defaultParams: SimulationRequest = {
  substrate_library: "FR4_epoxy",
  permittivity: 4.4,
  loss_tangent: 0.02,
  metal_material: "copper",
  metal_thickness_mm: 0.035,
  patch_width_mm: 38,
  patch_length_mm: null,
  substrate_thickness_mm: 1.6,
  probe_rel_x: 0.3,
  probe_radius_mm: 0.6,
  airbox_pad_mm: 30,
  f_center_ghz: 2.4,
  f_start_ghz: 2.0,
  f_stop_ghz: 2.8,
  max_passes: 6,
  graphical_aedt: false,
};
