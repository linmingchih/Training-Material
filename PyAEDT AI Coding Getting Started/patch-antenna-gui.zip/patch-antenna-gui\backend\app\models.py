from typing import Literal

from pydantic import BaseModel, Field


class SimulationRequest(BaseModel):
    substrate_library: Literal["custom", "FR4_epoxy", "Duroid (tm)"] = "FR4_epoxy"
    permittivity: float = Field(default=4.4, gt=1.0, lt=50.0)
    loss_tangent: float = Field(default=0.02, ge=0.0, lt=1.0)
    metal_material: str = "copper"
    metal_thickness_mm: float = Field(default=0.035, gt=0.0, lt=2.0)
    patch_width_mm: float = Field(default=38.0, gt=0.1, lt=500.0)
    patch_length_mm: float | None = Field(default=None, gt=0.1, lt=500.0)
    substrate_thickness_mm: float = Field(default=1.6, gt=0.05, lt=20.0)
    probe_rel_x: float = Field(default=0.3, ge=0.0, le=1.0)
    probe_radius_mm: float = Field(default=0.6, gt=0.05, lt=5.0)
    airbox_pad_mm: float = Field(default=30.0, gt=1.0, lt=200.0)
    f_center_ghz: float = Field(default=2.4, gt=0.1, lt=100.0)
    f_start_ghz: float = Field(default=2.0, gt=0.1, lt=100.0)
    f_stop_ghz: float = Field(default=2.8, gt=0.1, lt=100.0)
    max_passes: int = Field(default=6, ge=2, le=20)
    graphical_aedt: bool = False


class LogLine(BaseModel):
    level: Literal["info", "warning", "error"]
    text: str


class S11Result(BaseModel):
    expression: str
    freq_ghz: list[float]
    s11_db: list[float]
    f_res_ghz: float
    s11_min_db: float
    threshold_db: float
    f_low_ghz: float | None
    f_high_ghz: float | None
    bw_ghz: float | None
    frac_bw_pct: float | None
    q_factor: float | None


class JobStatus(BaseModel):
    job_id: str
    state: Literal["queued", "running", "completed", "failed", "cancelled"]
    messages: list[LogLine]
    result: S11Result | None = None
    error: str | None = None
