"""HFSS 3D probe-fed patch runner. Reads JSON params, writes dB(S11) JSON."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

import numpy as np
from ansys.aedt.core import Hfss, settings
from ansys.aedt.core.modeler.advanced_cad.stackup_3d import Stackup3D

settings.release_on_exception = False
settings.use_grpc_api = True

ROOT = Path(__file__).resolve().parents[2]
AEDT_VERSION = "2026.1"
NUM_CORES = min(8, os.cpu_count() or 4)


def find_grpc_port() -> int | None:
    locks = list((ROOT / "hfss").glob("*.aedt.lock"))
    jobs = ROOT / "jobs"
    if jobs.exists():
        locks.extend(jobs.rglob("*.aedt.lock"))
    for lock in locks:
        try:
            text = lock.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        for line in text.splitlines():
            if "GRPCPort" in line and "=" in line:
                return int(line.split("=")[1].strip())
    return None


def load_s11_curve(hfss):
    sweep = hfss.nominal_sweep
    print(f"nominal_sweep={sweep}", flush=True)
    print(f"existing_analysis_sweeps={hfss.existing_analysis_sweeps}", flush=True)
    setups_to_try = [s for s in (sweep, "Setup1 : Sweep1", "Setup1 : LastAdaptive") if s]
    categories = ["Terminal Solution Data", "Modal Solution Data"]
    expressions = []
    for category in categories:
        try:
            quantities = hfss.post.available_report_quantities(report_category=category, solution=sweep) or []
        except Exception as exc:  # noqa: BLE001
            print(f"quantities[{category}] error: {exc}", flush=True)
            quantities = []
        print(f"quantities[{category}]={quantities}", flush=True)
        for quantity in quantities:
            if quantity.startswith(("St(", "S(")):
                expressions.append((category, f"dB({quantity})", quantity))
    for port in hfss.excitation_names:
        expressions.append(("Terminal Solution Data", f"dB(St({port},{port}))", f"St({port},{port})"))
        expressions.append(("Modal Solution Data", f"dB(S({port},{port}))", f"S({port},{port})"))

    tried = set()
    for category, db_expr, raw_expr in expressions:
        for setup_name in setups_to_try:
            for expr, formula in ((db_expr, "real"), (raw_expr, "db20"), (raw_expr, "real")):
                key = (category, setup_name, expr, formula)
                if key in tried:
                    continue
                tried.add(key)
                data = hfss.post.get_solution_data(
                    expressions=expr,
                    setup_sweep_name=setup_name,
                    primary_sweep_variable="Freq",
                    report_category=category,
                    domain="Sweep",
                )
                if data in (False, None):
                    continue
                freq, s11 = data.get_expression_data(expression=expr, formula=formula)
                freq = np.asarray(freq, dtype=float)
                s11 = np.asarray(s11, dtype=float)
                if freq.size == 0 or s11.size == 0:
                    continue
                print(f"Loaded S11 via {category} | {setup_name} | {expr} | {formula}", flush=True)
                return expr, freq, s11
    raise RuntimeError("Failed to get dB(S11) from Terminal/Modal solution data")


def crossing_frequency(freq, s11, i_res, threshold, side):
    n = len(freq)
    if side == "left":
        for i in range(i_res, 0, -1):
            y0, y1 = s11[i], s11[i - 1]
            if y0 <= threshold < y1 or y1 <= threshold < y0:
                if y1 == y0:
                    return float(freq[i])
                t = (threshold - y0) / (y1 - y0)
                return float(freq[i] + t * (freq[i - 1] - freq[i]))
        return None
    for i in range(i_res, n - 1):
        y0, y1 = s11[i], s11[i + 1]
        if y0 <= threshold < y1 or y1 <= threshold < y0:
            if y1 == y0:
                return float(freq[i])
            t = (threshold - y0) / (y1 - y0)
            return float(freq[i] + t * (freq[i + 1] - freq[i]))
    return None


parser = argparse.ArgumentParser()
parser.add_argument("--params", required=True)
parser.add_argument("--out", required=True)
parser.add_argument("--job-dir", required=True)
args = parser.parse_args()

params = json.loads(Path(args.params).read_text(encoding="utf-8"))
job_dir = Path(args.job_dir)
out_path = Path(args.out)
project_path = job_dir / "patch.aedt"

f_center = float(params["f_center_ghz"])
f_start = float(params["f_start_ghz"])
f_stop = float(params["f_stop_ghz"])
width = float(params["patch_width_mm"])
length = params.get("patch_length_mm")
if length in (None, "", 0):
    length = None
else:
    length = float(length)
sub_h = float(params["substrate_thickness_mm"])
metal_t = float(params["metal_thickness_mm"])
probe_x = float(params["probe_rel_x"])
probe_r = float(params["probe_radius_mm"])
pad = float(params["airbox_pad_mm"])
max_passes = int(params["max_passes"])
graphical = bool(params.get("graphical_aedt", False))
library = params.get("substrate_library", "FR4_epoxy")
metal = params.get("metal_material", "copper")

print(f"Job directory: {job_dir}", flush=True)
port = find_grpc_port()
project_kwargs = {
    "project": str(project_path),
    "design": "Patch24GHz",
    "solution_type": "Terminal",
    "version": AEDT_VERSION,
    "close_on_exit": False,
}
if port:
    print(f"Connecting to AEDT gRPC port {port}", flush=True)
    hfss = Hfss(new_desktop=False, port=port, **project_kwargs)
else:
    print(f"Launching AEDT {AEDT_VERSION}", flush=True)
    hfss = Hfss(new_desktop=True, non_graphical=not graphical, **project_kwargs)

hfss.modeler.model_units = "mm"

if library == "custom":
    diel_name = "patch_sub"
    print(f"Custom substrate er={params['permittivity']} tand={params['loss_tangent']}", flush=True)
    mat = hfss.materials.add_material(diel_name)
    mat.permittivity = float(params["permittivity"])
    mat.dielectric_loss_tangent = float(params["loss_tangent"])
    if hasattr(mat, "update"):
        mat.update()
else:
    diel_name = library
    print(f"Library substrate: {diel_name}", flush=True)

print("Building Stackup3D patch...", flush=True)
stackup = Stackup3D(hfss, f_center * 1e9)
gnd = stackup.add_ground_layer("gnd", material=metal, thickness=metal_t, fill_material="air")
stackup.add_dielectric_layer("substrate", thickness=f"{sub_h}mm", material=diel_name)
top = stackup.add_signal_layer("signal", material=metal, thickness=metal_t, fill_material="air")
patch = top.add_patch(
    frequency=f_center * 1e9,
    patch_width=width,
    patch_length=length,
    patch_name="Patch",
)
stackup.resize_around_element(patch)
patch.create_probe_port(gnd, rel_x_offset=probe_x, r=probe_r)

print("Assigning radiation boundary...", flush=True)
pad_expr = f"{pad}mm"
region = hfss.modeler.create_region(
    pad_value=[pad_expr] * 6,
    pad_type="Absolute Offset",
    name="AirBox",
)
hfss.assign_radiation_boundary_to_objects(region)

print(f"Setup {f_center} GHz, sweep {f_start}-{f_stop} GHz", flush=True)
setup = hfss.create_setup(
    name="Setup1",
    setup_type="HFSSDriven",
    Frequency=f"{f_center}GHz",
    MaximumPasses=max_passes,
)
setup.create_frequency_sweep(
    unit="GHz",
    name="Sweep1",
    start_frequency=f_start,
    stop_frequency=f_stop,
    sweep_type="Interpolating",
    save_fields=False,
)
hfss.save_project()
print(f"Saved {hfss.project_file}", flush=True)
print(f"Analyzing Setup1 with {NUM_CORES} cores...", flush=True)
solved = hfss.analyze_setup("Setup1", cores=NUM_CORES)
print(f"analyze_setup returned {solved}", flush=True)
print(f"setup names={hfss.setup_names}", flush=True)

print("Extracting dB(S11)...", flush=True)
s11_expr, freq, s11 = load_s11_curve(hfss)
freq = np.asarray(freq, dtype=float)
s11 = np.asarray(s11, dtype=float)
if freq.size == 0:
    raise RuntimeError("Empty S11 sweep")
if freq.max() > 1e6:
    freq = freq / 1e9
elif freq.max() > 100:
    freq = freq / 1e3

i_res = int(np.argmin(s11))
f_res = float(freq[i_res])
s11_min = float(s11[i_res])
threshold = s11_min + 3.0
f_low = crossing_frequency(freq, s11, i_res, threshold, "left")
f_high = crossing_frequency(freq, s11, i_res, threshold, "right")
bw_ghz = None if f_low is None or f_high is None else float(f_high - f_low)
frac_bw = None if bw_ghz is None or f_res == 0 else 100.0 * bw_ghz / f_res
q_factor = None if bw_ghz in (None, 0) else f_res / bw_ghz

payload = {
    "expression": s11_expr,
    "freq_ghz": freq.tolist(),
    "s11_db": s11.tolist(),
    "f_res_ghz": f_res,
    "s11_min_db": s11_min,
    "threshold_db": threshold,
    "f_low_ghz": f_low,
    "f_high_ghz": f_high,
    "bw_ghz": bw_ghz,
    "frac_bw_pct": frac_bw,
    "q_factor": q_factor,
}
out_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
hfss.save_project()
print(f"Wrote {out_path}", flush=True)
print(f"fres={f_res:.4f} GHz  S11={s11_min:.2f} dB", flush=True)
