from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
import uuid
from pathlib import Path

from backend.app.models import JobStatus, LogLine, S11Result, SimulationRequest

ROOT = Path(__file__).resolve().parents[2]
RUNNER = ROOT / "backend" / "runners" / "simulate_patch.py"
JOBS_DIR = ROOT / "jobs"
PYTHON = Path(sys.executable)


class JobStore:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._jobs: dict[str, dict] = {}

    def create(self, params: SimulationRequest) -> str:
        job_id = uuid.uuid4().hex[:12]
        job_dir = JOBS_DIR / job_id
        job_dir.mkdir(parents=True, exist_ok=True)
        params_path = job_dir / "params.json"
        out_path = job_dir / "s11.json"
        params_path.write_text(params.model_dump_json(indent=2), encoding="utf-8")
        with self._lock:
            self._jobs[job_id] = {
                "state": "queued",
                "messages": [],
                "result": None,
                "error": None,
                "process": None,
                "params_path": params_path,
                "out_path": out_path,
                "job_dir": job_dir,
            }
        thread = threading.Thread(target=self._run, args=(job_id,), daemon=True)
        thread.start()
        return job_id

    def _append(self, job_id: str, level: str, text: str) -> None:
        line = LogLine(level=level, text=text.rstrip())
        with self._lock:
            self._jobs[job_id]["messages"].append(line)

    def _run(self, job_id: str) -> None:
        with self._lock:
            job = self._jobs[job_id]
            params_path = job["params_path"]
            out_path = job["out_path"]
            job_dir = job["job_dir"]
            job["state"] = "running"
        env = os.environ.copy()
        env["PYTHONUNBUFFERED"] = "1"
        cmd = [
            str(PYTHON),
            str(RUNNER),
            "--params",
            str(params_path),
            "--out",
            str(out_path),
            "--job-dir",
            str(job_dir),
        ]
        self._append(job_id, "info", "Starting HFSS 3D patch simulation...")
        try:
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                cwd=str(ROOT),
                env=env,
            )
            with self._lock:
                self._jobs[job_id]["process"] = process
            assert process.stdout is not None
            for raw in process.stdout:
                text = raw.rstrip()
                if not text:
                    continue
                level = "info"
                if "WARNING" in text.upper() or text.startswith("WARN"):
                    level = "warning"
                if "ERROR" in text.upper() or "TRACEBACK" in text.upper():
                    level = "error"
                self._append(job_id, level, text)
            code = process.wait()
            with self._lock:
                self._jobs[job_id]["process"] = None
                if self._jobs[job_id]["state"] == "cancelled":
                    return
            if code != 0 or not out_path.exists():
                with self._lock:
                    self._jobs[job_id]["state"] = "failed"
                    self._jobs[job_id]["error"] = f"Simulation exited with code {code}"
                self._append(job_id, "error", f"Simulation failed (exit {code})")
                return
            payload = json.loads(out_path.read_text(encoding="utf-8"))
            result = S11Result.model_validate(payload)
            with self._lock:
                self._jobs[job_id]["result"] = result
                self._jobs[job_id]["state"] = "completed"
            self._append(job_id, "info", "dB(S11) ready")
        except Exception as exc:  # noqa: BLE001
            with self._lock:
                if self._jobs[job_id]["state"] != "cancelled":
                    self._jobs[job_id]["state"] = "failed"
                    self._jobs[job_id]["error"] = str(exc)
            self._append(job_id, "error", str(exc))

    def status(self, job_id: str) -> JobStatus | None:
        with self._lock:
            job = self._jobs.get(job_id)
            if job is None:
                return None
            return JobStatus(
                job_id=job_id,
                state=job["state"],
                messages=list(job["messages"]),
                result=job["result"],
                error=job["error"],
            )

    def cancel(self, job_id: str) -> bool:
        with self._lock:
            job = self._jobs.get(job_id)
            if job is None or job["process"] is None:
                return False
            process = job["process"]
            job["state"] = "cancelled"
        process.terminate()
        self._append(job_id, "warning", "Simulation cancelled")
        return True


store = JobStore()
